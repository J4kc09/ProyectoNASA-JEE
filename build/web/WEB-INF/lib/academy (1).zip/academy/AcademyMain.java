package academy;

import java.io.PrintWriter;

public class AcademyMain {
    public static void main(String[] args) {
        Academy socrates = new Academy("SÓCRATES", "cursos.txt");
        socrates.writeAcademy("academia.txt"); 					  // Volcado de datos a fichero 
        socrates.writeAcademy(new PrintWriter(System.out, true)); // Volcado de datos a la pantalla 
    }
}
