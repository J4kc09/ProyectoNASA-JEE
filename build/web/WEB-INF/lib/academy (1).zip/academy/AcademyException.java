package academy;

public class AcademyException extends Exception {
	public AcademyException() {
		super();
	}
	public AcademyException(String m) {
		super(m);
	}
}
