package academy;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.InputMismatchException;
//import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Academy {
    private static final int TAM = 50;
    private String name;
    private int nCourses;
    private Course[] courses;

    public Academy(String name, String filename) {
        this.name = name;
        courses = new Course[TAM];
        try (Scanner sc = new Scanner(new File(filename))) {
            processFile(sc);
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void processFile(Scanner fich) {
        String line = null;
        while (fich.hasNextLine()) {
            try {
                line = fich.nextLine();
                Course c = processLine(line);
                if (nCourses == courses.length) {
                    courses = Arrays.copyOf(courses, courses.length * 2);
                }
                courses[nCourses] = c;
                nCourses++;
            } catch (InputMismatchException e) {
                System.err.println("Formato de datos incorrecto: " + line);
            } catch (NoSuchElementException e) {
                System.err.println("Datos incompletos: " + line);
            } catch (AcademyException ex) {
                System.err.println(ex.getMessage() +": "+line);
            }
        }
        courses = Arrays.copyOf(courses, nCourses);
    }

    private Course processLine(String line) throws InputMismatchException, NoSuchElementException, AcademyException 
    {
        Course c = null;
        try (Scanner sc = new Scanner(line)) {
            sc.useDelimiter("[;]+");
            //sc.useLocale(Locale.ENGLISH);
            String name = sc.next(); //System.out.print
            int days = sc.nextInt();
            double price = sc.nextDouble();
            int places = sc.nextInt();
            c = new Course(name, days, price, places);
        }
        return c;
    }

    public void writeAcademy(String f) {
        try (PrintWriter pw = new PrintWriter(f)) {
            writeAcademy(pw);
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + f);
        }
    }

    public void writeAcademy(PrintWriter pw) {
        pw.print(name + " academy - ");
        pw.println(nCourses + " courses");
        for (Course c : courses) {
            pw.println("\t"+c);
        }
    }
    
    
}
