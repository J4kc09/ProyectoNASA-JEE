package academy;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class CourseTest {
	public static void main(String[] args) throws AcademyException {
            Course c1 = new Course("Astronomía",10,300.0,20);
            Course c2 = new Course("Cocina",10,150.0,40);
            Course c3 = new Course("ABP",10,100.0,30);
            Course c4 = new Course ("Buceo",4,200.0,10);
            Set<Course> cc = new TreeSet<>(new OrdenPrecio());
            cc.add(c1);
            cc.add(c2);
            cc.add(c3);
            cc.add(c4);
            
            System.out.println(cc);
        }
}
