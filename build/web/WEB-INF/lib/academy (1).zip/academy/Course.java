package academy;

public class Course implements Comparable<Course> {

    private String name;
    private int numberOfDays;
    private double price;
    private int places;
    private int vacancies;

    public Course(String name, int days, double price, int places) throws AcademyException {
        if (places <= 0) {
            throw new AcademyException("Insufficient places: " + numberOfDays);
        }
        this.name = name;
        setNumberOfDays(days);
        setPrice(price);
        setPlaces(places);
        vacancies = places;
    }

    public String getName() {
        return name;
    }

    public int getNumberOfDays() {
        return numberOfDays;
    }

    public void setNumberOfDays(int numberOfDays) throws AcademyException {
        if (numberOfDays < 1 || numberOfDays > 20) {
            throw new AcademyException("Incorrect number of days: " + numberOfDays);
        } else {
            this.numberOfDays = numberOfDays;
        }
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getPlaces() {
        return places;
    }

    public void setPlaces(int places) {
        this.places = places;
    }

    public int getVacancies() {
        return vacancies;
    }

    public void enrol() throws AcademyException {
        if (vacancies == 0) {
            throw new AcademyException(name + " full course.");
        }
        vacancies--;
    }

    public String toString() {
        return name + ": " + numberOfDays + " days, " + price + " euros, " + places + " vacancies";
    }

    public boolean equals(Object obj) {
        boolean res = obj instanceof Course;
        if (res) {
            Course c = (Course) obj;
            res = c.getName().equalsIgnoreCase(this.name) && c.getNumberOfDays() == this.numberOfDays
                    && c.getPrice() == this.price && c.getPlaces() == this.places;
        }
        return res;
    }

    public int hashCode() {
        return name.toUpperCase().hashCode() + this.numberOfDays + Double.hashCode(price) + this.places;
    }

    @Override
    public int compareTo(Course o) {
        int res = this.name.compareTo(o.getName());
        if (res == 0) {
            //res = this.places-o.getPlaces();
            res = Integer.compare(this.places, o.places);
        }
        return res;
    }

}
